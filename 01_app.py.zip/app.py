import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Sales Deep-Dive Dashboard", page_icon="📊", layout="wide")
st.title("📊 Sales Deep-Dive & Interactive Dashboard")
st.caption("ApexPlanet Data Analytics — Task 3 | Explore sales performance, products, categories, cities and customer segments.")
@st.cache_data
def load_data():
    d = pd.read_csv("cleaned_sales_data.csv", parse_dates=["Order_Date"])
    d["Total_Sales"] = pd.to_numeric(d["Total_Sales"], errors="coerce")
    d["Quantity"] = pd.to_numeric(d["Quantity"], errors="coerce")
    return d.dropna(subset=["Order_Date", "Total_Sales"])
df = load_data()
with st.sidebar:
    st.header("Filters")
    min_date, max_date = df.Order_Date.min().date(), df.Order_Date.max().date()
    date_range = st.date_input("Order date range", value=(min_date, max_date), min_value=min_date, max_value=max_date)
    cities = st.multiselect("City", sorted(df.City.dropna().unique()), default=sorted(df.City.dropna().unique()))
    categories = st.multiselect("Category", sorted(df.Category.dropna().unique()), default=sorted(df.Category.dropna().unique()))
    genders = st.multiselect("Gender", sorted(df.Gender.dropna().unique()), default=sorted(df.Gender.dropna().unique()))
    products = st.multiselect("Product", sorted(df.Product.dropna().unique()), default=sorted(df.Product.dropna().unique()))
if isinstance(date_range, tuple) and len(date_range)==2:
    start, end = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1]) + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
else:
    start, end = pd.Timestamp(min_date), pd.Timestamp(max_date) + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
f = df[(df.Order_Date >= start) & (df.Order_Date <= end) & df.City.isin(cities) & df.Category.isin(categories) & df.Gender.isin(genders) & df.Product.isin(products)]
if f.empty:
    st.warning("No records match these filters. Adjust the filters in the sidebar.")
    st.stop()
total_sales = f.Total_Sales.sum(); unique_orders = f.Order_ID.nunique(); unique_customers = f.Customer_ID.nunique(); units = f.Quantity.sum()
# Note: repeated Order_IDs exist, so average sales/order is a proxy based on distinct order IDs.
aov_proxy = total_sales / unique_orders if unique_orders else 0
c1,c2,c3,c4,c5 = st.columns(5)
c1.metric("Total Sales", f"₹{total_sales:,.0f}")
c2.metric("Unique Orders", f"{unique_orders:,}")
c3.metric("Unique Customers", f"{unique_customers:,}")
c4.metric("Units Sold", f"{units:,.0f}")
c5.metric("Sales / Unique Order*", f"₹{aov_proxy:,.0f}")
st.caption("*Proxy metric: Order_ID occurs on multiple rows in this dataset, so interpret as sales divided by distinct order IDs.")
left,right = st.columns(2)
with left:
    cat = f.groupby('Category', as_index=False).Total_Sales.sum().sort_values('Total_Sales', ascending=False)
    st.plotly_chart(px.bar(cat, x='Category', y='Total_Sales', title='Sales by Category', text_auto='.2s'), use_container_width=True)
with right:
    monthly = f.assign(Month=f.Order_Date.dt.to_period('M').astype(str)).groupby('Month', as_index=False).Total_Sales.sum().sort_values('Month')
    st.plotly_chart(px.line(monthly, x='Month', y='Total_Sales', markers=True, title='Monthly Sales Trend'), use_container_width=True)
left,right = st.columns(2)
with left:
    city = f.groupby('City', as_index=False).Total_Sales.sum().sort_values('Total_Sales', ascending=False)
    st.plotly_chart(px.bar(city, x='Total_Sales', y='City', orientation='h', title='Sales by City'), use_container_width=True)
with right:
    product = f.groupby('Product', as_index=False).Total_Sales.sum().sort_values('Total_Sales', ascending=False)
    st.plotly_chart(px.pie(product, names='Product', values='Total_Sales', title='Sales Share by Product', hole=.35), use_container_width=True)
left,right = st.columns(2)
with left:
    gender = f.groupby('Gender', as_index=False).Total_Sales.sum()
    st.plotly_chart(px.bar(gender, x='Gender', y='Total_Sales', title='Sales by Gender'), use_container_width=True)
with right:
    st.subheader("Customer age distribution")
    st.plotly_chart(px.histogram(f, x='Age', nbins=12, title='Order Records by Customer Age'), use_container_width=True)
st.subheader("Filtered transaction data")
st.dataframe(f.sort_values('Order_Date', ascending=False), use_container_width=True, hide_index=True)
st.download_button("Download filtered data as CSV", f.to_csv(index=False).encode('utf-8'), file_name="filtered_sales_data.csv", mime="text/csv")
st.info("Business note: this dataset contains no customer activity history or customer status, so churn rate cannot be reliably calculated. Add retention-period data before reporting churn.")
