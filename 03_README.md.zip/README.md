# Sales Deep-Dive Analysis & Interactive Dashboard

**ApexPlanet Data Analytics — Task 3**

An interactive sales analytics dashboard built with Python, Pandas, Streamlit, and Plotly. It helps explore sales performance by date, city, product category, product, gender, and customer age.

## Project objectives

- Define business KPIs and document their formulas.
- Explore sales trends and segment performance.
- Provide an interactive dashboard with filters.
- Allow filtered transaction data to be downloaded as CSV.
- Summarize findings and recommendations in a report.

## Dashboard features

- KPI cards for total sales, unique orders, unique customers, units sold, and sales per unique order (proxy).
- Interactive filters for order date, city, category, gender, and product.
- Charts for category sales, monthly sales trends, city sales, product sales share, gender sales, and customer age distribution.
- Filtered transaction table and CSV download.

## Repository contents

| File | Description |
|---|---|
| `app.py` | Streamlit dashboard application |
| `cleaned_sales_data.csv` | Cleaned data used by the dashboard |
| `kpi_definitions.csv` | KPI definitions, formulas, and rationale |
| `category_sales_summary.csv` | Sales totals by category |
| `city_sales_summary.csv` | Sales totals by city |
| `monthly_sales_summary.csv` | Sales totals by month |
| `Task3_Deep_Dive_Report.pdf` | Written analysis report |
| `analysis_summary.txt` | Summary of headline findings and data notes |
| `requirements.txt` | Python dependencies |

## Run the dashboard locally

1. Install Python 3.10 or later.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

5. Start Streamlit:

   ```bash
   python -m streamlit run app.py
   ```

6. Open the local URL shown in the terminal (usually `http://localhost:8501`).

## Deploy online

You can deploy this repository with Streamlit Community Cloud:

1. Push the files to a GitHub repository.
2. Sign in to Streamlit Community Cloud and connect your GitHub account.
3. Select this repository and choose `app.py` as the main file.
4. Deploy the app, test the public URL, and add the URL here.

**Live dashboard:** Add your deployed URL here after publishing.

## Core KPIs

1. **Total Sales** = sum of `Total_Sales`.
2. **Unique Orders** = distinct count of `Order_ID`.
3. **Unique Customers** = distinct count of `Customer_ID`.
4. **Units Sold** = sum of `Quantity`.
5. **Sales per Unique Order (proxy)** = total sales divided by distinct order IDs.

The fifth KPI is labelled a proxy because some order IDs occur on multiple rows. Confirm the dataset's row-level grain with the data owner before interpreting it as a definitive average order value. Churn is not calculated because the dataset does not provide customer activity periods or a churn definition.

## Data-quality notes

- The supplied dataset contains 1,000 records and 12 columns.
- Missing age values are filled with the median in the cleaned dataset.
- Missing city values are labelled `Unknown`.
- Repeated order IDs are retained because rows may represent multiple items belonging to one order.
- Findings describe this supplied dataset and should not be treated as operational conclusions without validating the field definitions.

## Submission checklist

- [ ] Push project files to GitHub.
- [ ] Deploy the dashboard and add its public URL above.
- [ ] Record a 5–7 minute demo showing the KPIs, filters, charts, findings, and recommendations.
- [ ] Publish the demo on LinkedIn and tag **InAmigos Foundation**, as required by the task brief.
- [ ] Add the GitHub, dashboard, and LinkedIn post URLs to the final submission.
